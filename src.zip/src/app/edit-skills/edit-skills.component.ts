import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-skills',
  templateUrl: './edit-skills.component.html',
  styleUrls: ['./edit-skills.component.css']
})
export class EditSkillsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-completed',
  templateUrl: './user-completed.component.html',
  styleUrls: ['./user-completed.component.css']
})
export class UserCompletedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

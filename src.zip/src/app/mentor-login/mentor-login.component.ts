import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';

@Component({
  selector: 'app-mentor-login',
  templateUrl: './mentor-login.component.html',
  styleUrls: ['./mentor-login.component.css']
})
export class MentorLoginComponent implements OnInit {
email:string;
password:string;
  constructor(private route:Router) { }

  ngOnInit() {
  }
  validate(){
    if(this.email==null){
      alert("enter proper email");
    }else if(this.password==null){
      alert("Enter password");
    }else{
      this.route.navigate(['/mentor-landing']);
    }
  }
}

export class Mentor{
    username:string;
    contactnumber:Int16Array;
    experience:Int16Array;
    facilities:string;
    firstname:string;
    lastname:string;
    password:string;
    confirmpassword:string;
}
import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { AdminService } from "./../admin.service";
import { Admin } from "./../admin";

@Component({
  selector: 'app-admin-landing',
  templateUrl: './admin-landing.component.html',
  styleUrls: ['./admin-landing.component.css']
})
export class AdminLandingComponent implements OnInit {
  adminUsers: Observable<Admin[]>;
  adminMentors:Observable<Admin[]>;

  constructor(private adminService:AdminService) { }

  ngOnInit() {
    this.reloadData();
  }
  reloadData() {
    this.adminMentors=this.adminService.getMentorsList();
    this.adminUsers = this.adminService.getUsersList();
  }

}

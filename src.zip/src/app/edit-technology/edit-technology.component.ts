import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-technology',
  templateUrl: './edit-technology.component.html',
  styleUrls: ['./edit-technology.component.css']
})
export class EditTechnologyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

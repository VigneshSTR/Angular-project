import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mentor-completed',
  templateUrl: './mentor-completed.component.html',
  styleUrls: ['./mentor-completed.component.css']
})
export class MentorCompletedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

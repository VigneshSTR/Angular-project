import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
email:string;
password:string;
  constructor(private route:Router) { }

  ngOnInit() {
  }
  validate(){
  if(this.email==null){
    alert("enter proper email");
  }else if(this.password==null){
    alert("Enter password");
  }else{
    this.route.navigate(['/user-landing']);
  }
}
}
